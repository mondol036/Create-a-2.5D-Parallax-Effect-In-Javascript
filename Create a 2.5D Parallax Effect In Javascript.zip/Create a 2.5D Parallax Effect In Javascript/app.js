function parallax(element,distance,speed){
const items=document.querySelector(element);
items.style.transform=`translateY(${distance*speed}px)`
}

window.addEventListener('scroll',function(){
    parallax("header",window.scrollY,1);
    parallax('.small-rose',window.scrollY,0.4);
    parallax('.big-rose',window.scrollY,0.2);
})

